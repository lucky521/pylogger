#!/usr/bin/env python

from distutils.core import setup

setup(name='pylogger',
      version='1.0',
      description='Python Logger Utilities',
      author='Lucky',
      author_email='',
      url='https://github.com/lucky521',
      packages=[],
     )
